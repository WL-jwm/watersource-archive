import{r as s}from"./vendor-react-sAxhIgF9.js";import{Q as t}from"./calc-tools-BBaBJEtk.js";function m(){const r=t(o=>o.showConfirm);return s.useCallback(o=>r(o),[r])}export{m as u};
